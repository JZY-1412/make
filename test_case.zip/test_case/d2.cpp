#include "d2.h"

int area(int r) {
	return PI * r * r;
}