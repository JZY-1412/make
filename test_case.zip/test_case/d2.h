#include "d3.h"

int area(int r);