#include "d1.h"
#include "d2.h"
#include <cstdio>

#pragma comment(lib,"d0.lib")

int main() {
	printf("%d\n", add(1, 2));
	printf("%d\n", area(15));
	return 0;
}